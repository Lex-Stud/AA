Version 1.5.3
-------------

- more copyright updates in banner
- fixed MinGW cross-compilation (see 'BUILD.md')

Version 1.5.1
-------------

- fixed copyright and added two regression traces

Version 1.5.0
-------------

- added 'constrain' API call described in our FMCAD'21 paper

- replaced "`while () push_back ()`" with "`if () resize ()`" idiom
  (thanks go to Alexander Smal for pointing this out)
